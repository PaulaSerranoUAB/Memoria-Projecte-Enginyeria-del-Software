from django.shortcuts import render, HttpResponse

# Create your views here.
def home(request):
    return render(request,"home.html")

def xarxa_social(request):
    return render(request,"xarxa_social.html")

def perfil_medic(request):
    return render(request,"perfil_medic.html")

def posologia(request):
    return render(request,"posologia.html")

def son(request):
    return render(request,"son.html")

def constants_vitals(request):
    return render(request,"constants_vitals.html")

def activitat_fisica(request):
    return render(request,"activitat_fisica.html")